/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;
import conexãobanco.ConexaoComBanco;
import modelo.Canais;
import java.sql.*;
// Providencia ao NetBeans o acesso e o processamento de dados em um banco de dados.
import java.sql.PreparedStatement;
// Um objeto que representa um pre-compilado de argumentos no SQL, podendo ser executado varias vezes.

public class CanaisDAO {
    private Connection connection;
    
    public CanaisDAO(){
        this.connection = new ConexaoComBanco().getConnection();
    }
    public void adicionanomecanal(Canais canais){
        String sql = "INSERT INTO canais(nome_canal) VALUES(?)";
        try{
            PreparedStatement stmt1 = connection.prepareStatement(sql);
            stmt1.setString(1, canais.getNomecanal());
            stmt1.execute();
        }
        catch (SQLException u){
            throw new RuntimeException(u);
        }
    }    
    public void adicionatipocanal(Canais canais){
        String sql = "INSERT INTO canais(tipo_canal) VALUES(?)";
        try{
            PreparedStatement stmt2 = connection.prepareStatement(sql);
            stmt2.setString(1, canais.getTipocanal());
            stmt2.execute();
        }
        catch (SQLException u){
            throw new RuntimeException(u);
        }
    }
    public void adicionapadraoautentificacao(Canais canais){
        String sql = "INSERT INTO canais(padrao_autentificacao) VALUES(?)";
        try{
            PreparedStatement stmt3 = connection.prepareStatement(sql);
            stmt3.setString(1, canais.getPadraoautentificacao());
            stmt3.execute();
        }
        catch (SQLException u){
            throw new RuntimeException(u);
        }
    }
}
